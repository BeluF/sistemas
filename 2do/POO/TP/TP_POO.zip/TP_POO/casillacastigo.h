#ifndef CASILLA_CASTIGO_H
#define CASILLA_CASTIGO_H

#include "casilla.h"      // Necesita la clase base Casilla
#include "jugador.h"      // Necesita la clase Jugador para sus métodos y enum estadoJugador
#include "estadoJugador.h" // Incluye el enum

class CasillaCastigo : public Casilla
{
public:
    CasillaCastigo(int numero);
    void activarJugador(Jugador *jugador) override;
};

#endif // CASILLA_CASTIGO_H
