#ifndef CASILLA_NORMAL_H
#define CASILLA_NORMAL_H

#include "casilla.h" // Necesita la clase base Casilla

class CasillaNormal : public Casilla
{
public:
    CasillaNormal(int numero);
    void activarJugador(Jugador *jugador) override;
};

#endif // CASILLA_NORMAL_H
