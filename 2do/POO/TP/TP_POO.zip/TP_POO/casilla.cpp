#include "casilla.h"
#include <iostream> // Aunque no se use directamente aquí, si se usa en la clase Casilla en general.

using namespace std;

// Implementación del constructor de Casilla
Casilla::Casilla(int numero) : numero(numero) {}

// Implementación del getter
int Casilla::getnumero()
{
    return numero;
}
// El método activarJugador es virtual puro, no se implementa aquí.
