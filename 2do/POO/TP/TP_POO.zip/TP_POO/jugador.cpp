#include "jugador.h"
#include "casilla.h"      // Necesita la definición completa de Casilla
#include "estadoJugador.h" // Necesita la definición del enum
#include <iostream>       // Para cout (si se usa en algún método del jugador)

using namespace std;

// Constructor
Jugador::Jugador(string nombre) : nombre(nombre), posicion(0), turnosPerdidos(0), estadoEspecial(noCastigado) {}

string Jugador::getNombre() { return nombre; }
int Jugador::getPosicion() { return posicion; }
int Jugador::setPosicion(int nuevaPosicion)
{
    posicion = nuevaPosicion;
    return posicion; // Se mantiene el retorno int como estaba en tu código
}
void Jugador::mover(int cantidad) { posicion += cantidad; }
void Jugador::aplicarEfectoCasilla(Casilla *casilla)
{
    casilla->activarJugador(this); // Invoca el método activarJugador de la casilla actual, pasando el jugador actual
}
void Jugador::resetEstado() { estadoEspecial = noCastigado; turnosPerdidos = 0; } // Añadido reset de turnosPerdidos
bool Jugador::estaCastigado() { return (estadoEspecial == castigado) ? true : false; }
int Jugador::getTurnosPerdidos() { return turnosPerdidos; }
int Jugador::setTurnosPerdidos(int turnos)
{
    turnosPerdidos = turnos;
    return turnosPerdidos;
}
estadoJugador Jugador::getEstadoEspecial()
{
    return estadoEspecial;
}
void Jugador::setEstadoEspecial(estadoJugador nuevoEstado)
{
    estadoEspecial = nuevoEstado;
}
