#ifndef JUEGO_H
#define JUEGO_H
#include "dado.h"
#include "jugador.h"
#include "tablero.h"


// --- CLASE Juego ---
// La clase principal que coordina todo el sistema del juego de la Oca.
class Juego
{
private:
    Jugador **jugadores;
    int cantidadJugadores;
    Tablero *tablero;
    Dado dado;
    int turnoActual;
    bool terminado;

    const static int CASILLA_META = 62; // La última casilla (63) es el índice 62

public:
    Juego();
    ~Juego();
    void iniciar();
    void jugarTurno();
    void verificarGanador();
    void mostrarEstado() const;
    bool estaTerminado() const;

private:
    void avanzarTurno();
};

#endif // JUEGO_H
