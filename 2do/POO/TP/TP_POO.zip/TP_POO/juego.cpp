#include "juego.h"
#include "jugador.h" // Necesita la definición completa de Jugador
#include "tablero.h" // Necesita la definición completa de Tablero
#include "dado.h"    // Necesita la definición completa de Dado
#include <iostream>  // Para std::cout, std::cerr, std::cin
#include <limits>    // Para std::numeric_limits
#include <string>    // Para std::string (Aunque jugador.h lo incluye, es buena práctica si se usa directamente aquí)

using namespace std;

// Constructor
Juego::Juego() : jugadores(nullptr), cantidadJugadores(0), tablero(nullptr), turnoActual(0), terminado(false) {}

// Destructor: Libera la memoria asignada dinámicamente.
Juego::~Juego()
{
    if (jugadores)
    {
        for (int i = 0; i < cantidadJugadores; ++i)
        {
            delete jugadores[i]; // Libera cada Jugador
        }
        delete[] jugadores; // Libera el arreglo de punteros
    }
    delete tablero; // Libera el Tablero
}

// Método iniciar(): Pide nombres e inicializa jugadores y tablero.
void Juego::iniciar()
{
    // cout << "--- ¡Bienvenido al Juego de la Oca! ---" << endl; // Comentado según tu código
    do
    {
        cout << "¿Cuántos jugadores van a participar? (2-4): ";
        cin >> cantidadJugadores;
        if (cin.fail() || cantidadJugadores < 2 || cantidadJugadores > 4)
        {
            cout << "Número de jugadores inválido. Ingresa un número entre 2 y 4." << endl;
            cin.clear();                                         // Limpia el estado de error del cin para permitir nuevas entradas
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignora todo lo que haya quedado en el buffer hasta el final de la linea
        }
        else
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            break;
        }
    } while (true);

    jugadores = new Jugador *[cantidadJugadores];
    for (int i = 0; i < cantidadJugadores; ++i)
    {
        string nombreJugador;
        cout << "Ingrese el nombre del Jugador " << i + 1 << ": ";
        getline(cin, nombreJugador);
        jugadores[i] = new Jugador(nombreJugador);
    }

    tablero = new Tablero(63); // 63 casillas
    tablero->inicializar();    // Inicializa el tablero con las casillas correspondientes

    // cout << "\n¡El juego ha comenzado con " << cantidadJugadores << " jugadores!" << endl; // Comentado según tu código
    mostrarEstado(); // Muestra el estado inicial del juego (tablero y jugadores)
}

// Método jugarTurno(): Gestiona el turno del jugador actual.
void Juego::jugarTurno()
{
    if (terminado)
        return;

    Jugador *jugadorActual = jugadores[turnoActual];
    cout << "\n--- Turno de " << jugadorActual->getNombre() << " (Posición actual: " << jugadorActual->getPosicion() + 1 << ") ---" << endl;

    if (jugadorActual->estaCastigado())
    {
        if (jugadorActual->getTurnosPerdidos() > 0)
        {
            cout << jugadorActual->getNombre() << " está castigado y pierde el turno. Turnos restantes: " << jugadorActual->getTurnosPerdidos() << "." << endl;
            jugadorActual->setTurnosPerdidos(jugadorActual->getTurnosPerdidos() - 1);
        }
        else
        {
            jugadorActual->resetEstado(); // Reinicia el estado del jugador si ya no tiene turnos perdidos
            cout << jugadorActual->getNombre() << " ha terminado su castigo y puede jugar." << endl;
        }

        avanzarTurno();
        return;
    }

    int tirada = dado.tirar();
    cout << jugadorActual->getNombre() << " tiró el dado y obtuvo un " << tirada << "." << endl;

    int nuevaPosicion = jugadorActual->getPosicion() + tirada; // Calcula la nueva posición sumando la tirada a la posición actual

    // Si el jugador cae exactamente en la casilla 63
    if (nuevaPosicion == CASILLA_META)
    {
        cout << jugadorActual->getNombre() << " ha llegado a la casilla 63 y ha ganado el juego!" << endl;
        jugadorActual->setPosicion(CASILLA_META); // Asegura que el jugador llegue a la meta
    }

    // Si la nueva posición supera la casilla 63
    else if (nuevaPosicion > CASILLA_META)
    {
        int excedente = nuevaPosicion - CASILLA_META; // Calcula el excedente
        nuevaPosicion = CASILLA_META - excedente;     // Si se pasa, empieza a descontar desde la meta hacia atrás
        cout << jugadorActual->getNombre() << " se pasó de la meta y retrocede a la casilla " << nuevaPosicion + 1 << "." << endl; // +1 para mostrar en 1-based
        jugadorActual->setPosicion(nuevaPosicion);
    }

    // Movimiento normal
    else
    {
        jugadorActual->mover(tirada);
        cout << jugadorActual->getNombre() << " avanzó a la casilla " << jugadorActual->getPosicion() + 1 << "." << endl; // Añadido mensaje de avance normal
    }

    // Aplicar el efecto de la casilla a la que llegó
    Casilla *casillaLlegada = tablero->getCasilla(jugadorActual->getPosicion()); // Obtiene la casilla en la que el jugador ha caído
    if (casillaLlegada)
    {                                                        // Verifica que la casilla existe
        jugadorActual->aplicarEfectoCasilla(casillaLlegada); // Aplica el efecto de la casilla al jugador actual
    }

    // Verificar si hay un ganador después de aplicar el efecto
    verificarGanador();

    // Si no hay ganador, avanzar al siguiente turno
    if (!terminado)
    {
        avanzarTurno();
    }
}

// Método verificarGanador(): Determina si algún jugador alcanzó la casilla 63.
void Juego::verificarGanador()
{
    for (int i = 0; i < cantidadJugadores; ++i)
    {
        if (jugadores[i]->getPosicion() == CASILLA_META)
        // Se debe mostrar la casilla 63, no 62
        {
            cout << "\n¡FELICITACIONES! " << jugadores[i]->getNombre() << " ha llegado a la casilla " << CASILLA_META +1 << " y ha GANADO el juego!" << endl;
            terminado = true;
            return;
        }
    }
}

// Método mostrarEstado(): Imprime un resumen del estado actual.
void Juego::mostrarEstado() const
{
    cout << "\n--- Estado Actual del Juego ---" << endl;
    tablero->mostrar(); // Muestra el estado del tablero
    cout << "\nPosiciones de los Jugadores:" << endl;
    for (int i = 0; i < cantidadJugadores; ++i)
    {
        cout << "- " << jugadores[i]->getNombre() << ": Casilla " << jugadores[i]->getPosicion() + 1; // Muestra el nombre y la posición actual del jugador
        // Si el jugador está castigado, muestra los turnos perdidos
        if (jugadores[i]->estaCastigado())
        {
            cout << " (Castigado, pierde " << jugadores[i]->getTurnosPerdidos() << " turno(s))";
        }
        cout << endl;
    }
    cout << "Turno actual: " << jugadores[turnoActual]->getNombre() << endl;
    // cout << "-------------------------------" << endl; // Comentado según tu código
}

// Método estaTerminado(): Retorna true si el juego ha terminado.
bool Juego::estaTerminado() const
{
    return terminado;
}

// Método auxiliar para avanzar al siguiente turno.
void Juego::avanzarTurno()
{
    turnoActual = (turnoActual + 1) % cantidadJugadores;
}
