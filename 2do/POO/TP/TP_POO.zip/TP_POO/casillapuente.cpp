#include "casillapuente.h"
#include "jugador.h"       // Para usar Jugador y sus métodos
#include "estadoJugador.h" // Para usar el enum estadoJugador
#include <iostream>        // Para cout

using namespace std;

CasillaPuente::CasillaPuente(int numero) : Casilla(numero) {}

void CasillaPuente::activarJugador(Jugador *jugador)
{
    if (jugador == nullptr)
        return;
    jugador->setPosicion(12);
    jugador->setEstadoEspecial(noCastigado);
    cout << jugador->getNombre() << " cruza el puente y avanza a la casilla 13!" << endl;
}
