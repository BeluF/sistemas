#ifndef CASILLA_PUENTE_H
#define CASILLA_PUENTE_H

#include "casilla.h"      // Necesita la clase base Casilla
#include "jugador.h"      // Necesita la clase Jugador para sus métodos
#include "estadoJugador.h" // Incluye el enum

class CasillaPuente : public Casilla
{
public:
    CasillaPuente(int numero);
    void activarJugador(Jugador *jugador) override;
};

#endif // CASILLA_PUENTE_H
