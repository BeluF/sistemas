#include "juego.h"   // Incluye la declaración de la clase Juego
#include <iostream>  // Para std::cout, std::cin
#include <limits>    // Para std::numeric_limits

using namespace std;

int main()
{
    Juego miJuego;

    miJuego.iniciar();

    while (!miJuego.estaTerminado())
    {
        cout << "\nPresiona ENTER para continuar con el siguiente turno...";
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Limpia el buffer antes de esperar la entrada
        cin.get(); // Espera la pulsación de ENTER

        miJuego.jugarTurno();
        if (!miJuego.estaTerminado())
        {
            miJuego.mostrarEstado();
        }
    }

    cout << "\n¡El juego ha finalizado! Gracias por jugar." << endl;

    return 0;
}
