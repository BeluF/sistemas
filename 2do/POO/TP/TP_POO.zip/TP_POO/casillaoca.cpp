#include "casillaoca.h"
#include "jugador.h"       // Para usar Jugador y sus métodos
#include "estadoJugador.h" // Para usar el enum estadoJugador
#include <iostream>        // Para cout

using namespace std;

CasillaOca::CasillaOca(int numero) : Casilla(numero) {}

void CasillaOca::activarJugador(Jugador *jugador)
{
    if (jugador == nullptr)
        return;

    // Ejemplo de lógica para casilla Oca: avanzar a la siguiente Oca
    const int cantidadCasillasOca = 6;
    int casillasOca[cantidadCasillasOca] = {9, 18, 27, 36, 45, 54};
    // ----------- CAMBIAR EN INICIALIZAR TABLERO -------

    int pos = getnumero();
    for (int i = 0; i < cantidadCasillasOca - 1; i++)
    {
        if (pos == casillasOca[i])
        {
            jugador->setPosicion(casillasOca[i + 1]);
            // El estado debe ser NoCastigado
            jugador->setEstadoEspecial(noCastigado);
            cout << jugador->getNombre() << " avanza de Oca a Oca a la casilla " << casillasOca[i + 1] + 1 << "!" << endl;
            // break; // Este break estaba comentado, lo mantengo así
        }
    }
}
