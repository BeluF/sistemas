#ifndef CASILLA_OCA_H
#define CASILLA_OCA_H

#include "casilla.h"      // Necesita la clase base Casilla
#include "jugador.h"      // Necesita la clase Jugador para sus métodos
#include "estadoJugador.h" // Incluye el enum

class CasillaOca : public Casilla
{
public:
    CasillaOca(int numero);
    void activarJugador(Jugador *jugador) override;
};

#endif // CASILLA_OCA_H
