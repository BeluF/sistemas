#include "tablero.h"
#include "casilla.h"        // Asume que Casilla.h declara la clase base abstracta Casilla
#include "casillanormal.h"  // Asume CasillaNormal.h contiene la declaración de CasillaNormal
#include "casillaoca.h"     // Asume CasillaOca.h contiene la declaración de CasillaOca
#include "casillapuente.h"  // Asume CasillaPuente.h contiene la declaración de CasillaPuente
#include "casillacastigo.h" // Asume CasillaCastigo.h contiene la declaración de CasillaCastigo
#include <iostream>         // Para std::cout, std::cerr

using namespace std;

// Constructor: Inicializa el tablero con una cantidad específica de casillas.
Tablero::Tablero(int totalCasillas) : cantidadCasillas(totalCasillas)
{
    casillas = new Casilla *[cantidadCasillas]; // Reserva memoria para el arreglo de punteros a Casilla.
}

// Destructor: Libera la memoria asignada dinámicamente para las casillas.
Tablero::~Tablero()
{
    for (int i = 0; i < cantidadCasillas; ++i)
    {
        delete casillas[i]; // Libera cada objeto Casilla.
    }
    delete[] casillas; // Libera el arreglo de punteros.
}

// Método inicializar(): Crea cada casilla e instancia el tipo que corresponda.
void Tablero::inicializar()
{
    // cout << "Inicializando tablero con " << cantidadCasillas << " casillas..." << endl; // Comentado según tu código
    for (int i = 0; i < cantidadCasillas; ++i)
    {
        // Instanciar diferentes tipos de casillas según las relgas del juego.
        // Casillas de la Oca (índices 0-based)
        if (i == 9 || i == 18 || i == 27 || i == 36 || i == 45 || i == 54)
        {
            casillas[i] = new CasillaOca(i);
        }
        // Fin Casillas de la Oca

        // Casillas Puente (índice 0-based)
        else if (i == 6)
        {
            casillas[i] = new CasillaPuente(i);
        }
        // Fin Casillas Puente

        // Casillas Castigo: Posada (19), Pozo (31), Laberinto (42), Cárcel (56), Calavera (58) (índices 0-based)
        else if (i == 19 || i == 31 || i == 42 || i == 56 || i == 58)
        {
            casillas[i] = new CasillaCastigo(i);
        }
        // Fin Casillas Castigo

        // Casilla normal
        else
        {
            casillas[i] = new CasillaNormal(i);
        }
        // Fin Casilla normal
    }
    // cout << "Tablero inicializado." << endl; // Comentado según tu código
}

// Acceder a la casilla según la posición.
Casilla *Tablero::getCasilla(int pos) const
{
    if (pos >= 0 && pos < cantidadCasillas)
    {
        return casillas[pos];
    }
    // cerr << "Error: Posición de casilla fuera de rango: " << pos + 1 << endl; // Comentado según tu código
    return nullptr;
}

// Método mostrar(): Imprime un resumen del estado del tablero.
void Tablero::mostrar() const
{
    // cout << "\n--- Estado del Tablero ---" << endl; // Comentado según tu código
    for (int i = 0; i < cantidadCasillas; ++i)
    {
        cout << (i + 1); // Muestra el número de casilla (i+1)
            // Separar números con guiones para que el tablero sea más legible
        if (i < cantidadCasillas - 1)
        {
            cout << " - ";
        }
    }
    // cout << "\n--------------------------" << endl; // Comentado según tu código
}

// Retorna la cantidad total de casillas en el tablero.
int Tablero::getCantidadCasillas() const
{
    return cantidadCasillas;
}
