#include "casillanormal.h"
#include <iostream> // Para cout (aunque aquí no se usa, lo mantengo por si se añade lógica de mensaje)

using namespace std;

CasillaNormal::CasillaNormal(int numero) : Casilla(numero) {}

void CasillaNormal::activarJugador(Jugador *jugador)
{
    // No tiene efecto especial, simplemente no hace nada.
    // cout << jugador->getNombre() << " cae en una casilla normal (" << getnumero() + 1 << ")." << endl;
}
